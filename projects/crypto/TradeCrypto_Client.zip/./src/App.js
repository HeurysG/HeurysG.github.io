import React, { useState } from "react";
import NavBar from "./components/NavBar.js";
import ContentFrame from "./components/ContentFrame";
import Divider from "@mui/material/Divider";

function App() {
  const [isProcessingPort, setIsProcessingPort] = useState(false);
  const [isProcessingInsi, setIsProcessingInsi] = useState(false);
  const [performanceData, setPerformanceData] = useState();
  const [insights, setInsights] = useState();
  const [currentPage, setCurrentPage] = useState("userPreferences");

  return (
    <div style={{ display: "flex" }}>
      <NavBar
        isProcessingPort={isProcessingPort}
        isProcessingInsi={isProcessingInsi}
        currentPage={currentPage}
        setCurrentPage={setCurrentPage}
        insights={insights}
        performanceData={performanceData}
      />
      <Divider
        orientation="vertical"
        flexItem
        style={{ marginLeft: "10px", marginRight: "10px" }}
      />
      <ContentFrame
        isProcessingPort={isProcessingPort}
        setIsProcessingPort={setIsProcessingPort}
        isProcessingInsi={isProcessingInsi}
        setIsProcessingInsi={setIsProcessingInsi}
        currentPage={currentPage}
        insights={insights}
        setInsights={setInsights}
        performanceData={performanceData}
        setPerformanceData={setPerformanceData}
      />
    </div>
  );
}
export default App;
