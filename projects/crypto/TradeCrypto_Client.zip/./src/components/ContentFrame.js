import React, { useState } from "react";
import UserPreferences from "./UserPreferences";
import Divider from "@mui/material/Divider";
import PortfolioInformation from "./PortfolioInformation";
import PortfolioPerformance from "./PortfolioPerformance";
import PortfolioInsights from "./PortfolioInsights";
import PerformanceBacktesting from "./PerformanceBacktesting";
import BacktestingResults from "./BacktestingResults";
import LoadingPopUp from "./LoadingPopUp";

function ContentFrame({
  isProcessingPort,
  setIsProcessingPort,
  isProcessingInsi,
  setIsProcessingInsi,
  currentPage,
  insights,
  setInsights,
  performanceData,
  setPerformanceData,
}) {
  const [preferences, setPreferences] = useState({
    riskTolerance: "",
    minMarketCap: 1000000000,
    maxMarketCap: 1000000000000,
  });

  const [portfolioAssets, setPortfolioAssets] = useState([]);
  const [analysisReady, setAnalysisReady] = useState(false);
  const [analysisData, setAnalysisData] = useState({});
  const [marketData, setMarketData] = useState();
  const [presentDate, setPresentDate] = useState();
  const [numberOfTickers, setNumberOfTickers] = useState();
  const [isTraining, setIsTraining] = useState(false);
  const [loadingMessage, setLoadingMessage] = useState("");
  const [isFetchingMarketData, setIsFetchingMarketData] = useState(false);

  return (
    <div
      style={{
        flex: 1,
        padding: "20px",
        overflowY: "auto",
        background: "#FBFCFD",
      }}
    >
      {(!marketData || isTraining) && currentPage === "userPreferences" && (
        <UserPreferences
          preferences={preferences}
          setPreferences={setPreferences}
          presentDate={presentDate}
          setPresentDate={setPresentDate}
          setNumberOfTickers={setNumberOfTickers}
          setIsTraining={setIsTraining}
          setLoadingMessage={setLoadingMessage}
          setIsFetchingMarketData={setIsFetchingMarketData}
          setMarketData={setMarketData}
        />
      )}
      <LoadingPopUp
        open={isFetchingMarketData || isTraining}
        loadingMessage={loadingMessage}
        isFetchingMarketData={isFetchingMarketData}
        numberOfTickers={numberOfTickers}
        isTraining={isTraining}
      />
      {marketData &&
        !isTraining &&
        !isFetchingMarketData &&
        currentPage === "userPreferences" && (
          <PortfolioInformation
            isProcessingPort={isProcessingPort}
            setIsProcessingPort={setIsProcessingPort}
            isProcessingInsi={isProcessingInsi}
            setIsProcessingInsi={setIsProcessingInsi}
            assets={portfolioAssets}
            setAssets={setPortfolioAssets}
            setInsights={setInsights}
            marketData={marketData}
            presentDate={presentDate}
            setPerformanceData={setPerformanceData}
          />
        )}
      {currentPage === "portfolioPerformance" && (
        <PortfolioPerformance performanceData={performanceData} />
      )}
      {currentPage === "portfolioInsights" && (
        <PortfolioInsights insights={insights} />
      )}
      {currentPage === "portfolioInsights" && (
        <Divider
          style={{
            backgroundColor: "grey",
            height: "1px",
            margin: "10px 0",
          }}
        />
      )}
      {currentPage === "portfolioInsights" && !analysisReady && (
        <PerformanceBacktesting
          portfolio={portfolioAssets}
          insights={insights}
          setAnalysisReady={setAnalysisReady}
          setAnalysisData={setAnalysisData}
          presentDate={presentDate}
        />
      )}
      {currentPage === "portfolioInsights" && analysisReady && (
        <BacktestingResults
          analysisData={analysisData}
          setAnalysisReady={setAnalysisReady}
        />
      )}
    </div>
  );
}

export default ContentFrame;
