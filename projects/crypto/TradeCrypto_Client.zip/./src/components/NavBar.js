import React from "react";
import NavBarProfile from "./NavBarProfile";
import Divider from "@mui/material/Divider";
import NavBarItems from "./NavBarItems";
import userPhoto from "../static/images/user_profile.jpg";

function Navbar({
  isProcessingPort,
  isProcessingInsi,
  currentPage,
  setCurrentPage,
  insights,
  performanceData,
}) {
  const user = {
    name: "George Burdell",
    photo: userPhoto,
  };

  return (
    <div
      style={{
        width: "222px",
        height: "100vh",
        background: "#ffffff",
        display: "flex",
        flexDirection: "column",
      }}
    >
      <NavBarProfile user={user} />
      <Divider />
      <NavBarItems
        isProcessingPort={isProcessingPort}
        isProcessingInsi={isProcessingInsi}
        currentPage={currentPage}
        setCurrentPage={setCurrentPage}
        insights={insights}
        performanceData={performanceData}
      />
    </div>
  );
}

export default Navbar;
