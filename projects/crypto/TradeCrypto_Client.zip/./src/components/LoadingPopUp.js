import React, { useState, useEffect } from "react";
import {
  Dialog,
  LinearProgress,
  DialogContent,
  DialogContentText,
  CircularProgress,
} from "@mui/material";

function LoadingPopUp({
  open,
  loadingMessage,
  isFetchingMarketData,
  numberOfTickers,
  isTraining,
}) {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    if (open) {
      if (isFetchingMarketData) {
        return;
      }

      const interval = setInterval(() => {
        fetch("/api/trainingProgress")
          .then((response) => response.json())
          .then((data) => {
            const filesCount = data.filesCount;
            const progressPercentage = (filesCount / numberOfTickers) * 100;

            setProgress(progressPercentage);
          });
      }, 1000);

      return () => clearInterval(interval);
    }
  }, [open, isFetchingMarketData, isTraining, numberOfTickers]);

  return (
    <Dialog open={open}>
      <DialogContent style={{ textAlign: "center" }}>
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            width: "100%",
          }}
        >
          {isFetchingMarketData && <CircularProgress />}
          {isTraining && (
            <LinearProgress
              variant="determinate"
              value={progress}
              style={{ width: "100%" }}
            />
          )}
          <DialogContentText style={{ marginTop: "20px" }}>
            {loadingMessage}
          </DialogContentText>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export default LoadingPopUp;
