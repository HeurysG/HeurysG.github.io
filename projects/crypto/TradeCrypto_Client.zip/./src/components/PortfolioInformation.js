import React, { useState } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  TextField,
  Typography,
  IconButton,
  Fab,
  CircularProgress,
  Autocomplete,
} from "@mui/material";

import AddIcon from "@mui/icons-material/Add";
import PlayArrowIcon from "@mui/icons-material/PlayArrow";
import DeleteIcon from "@mui/icons-material/Delete";
import BarChartIcon from "@mui/icons-material/BarChart";

function PortfolioInformation({
  isProcessingPort,
  setIsProcessingPort,
  isProcessingInsi,
  setIsProcessingInsi,
  assets,
  setAssets,
  setInsights,
  marketData,
  presentDate,
  setPerformanceData,
}) {
  const input3dEffect = {
    borderRadius: "15px",
    boxShadow: "0px 4px 6px rgba(0, 0, 0, 0.1)",
    padding: "12px 12px",
    border: "none",
    fontSize: "14px",
    outline: "none",
    width: "200px",
    textAlign: "center",
  };

  const [showError, setShowError] = useState(false);

  let bitcoinPrice;

  const getBitcoinPrice = () => {
    const bitcoinData = marketData.find(
      (asset) => asset.crypto_name === "Bitcoin"
    );
    return bitcoinData ? bitcoinData.price_usd : null;
  };

  const handleAddNewAsset = () => {
    setAssets([
      ...assets,
      { assetName: "", amount: 0, positionBTC: 0, positionUSD: 0, alloc: 0.0 },
    ]);
  };

  const handleInputChange = (index, field, value) => {
    const newAssets = [...assets];

    newAssets[index][field] = value === "" ? 0 : value;

    if (bitcoinPrice === undefined) {
      bitcoinPrice = getBitcoinPrice();
    }

    let updatedTotalPositionUSD = 0;

    for (const asset of newAssets) {
      const selectedAsset = marketData.find(
        (mData) => mData.crypto_name === asset.assetName
      );

      if (selectedAsset) {
        const priceUSD = selectedAsset.price_usd;
        asset.positionBTC =
          ((parseFloat(asset.amount) || 0) * priceUSD) / bitcoinPrice;
        asset.positionUSD = (parseFloat(asset.amount) || 0) * priceUSD;
      }

      updatedTotalPositionUSD += asset.positionUSD || 0;
    }
    newAssets.forEach((asset) => {
      asset.alloc =
        updatedTotalPositionUSD !== 0
          ? asset.positionUSD / updatedTotalPositionUSD
          : 0;
    });

    setAssets(newAssets);
  };

  const handleDeleteAsset = (index) => {
    const newAssets = [...assets];
    newAssets.splice(index, 1);
    setAssets(newAssets);
  };

  const totalPositionBTC = assets.reduce(
    (acc, asset) => acc + asset.positionBTC,
    0
  );
  const totalPositionUSD = assets.reduce(
    (acc, asset) => acc + asset.positionUSD,
    0
  );

  const handleAnalysis = () => {
    if (assets.length === 0 || totalPositionUSD === 0) {
      setShowError(true);
      return;
    } else {
      setShowError(false);
    }
    setIsProcessingPort(true);
    const requestOptions = {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        presentDate: presentDate,
        assets: assets,
      }),
    };

    fetch("/api/performanceAnalysis", requestOptions)
      .then((response) => {
        if (!response.ok) {
          throw new Error("Network response was not ok");
        }
        return response.json();
      })
      .then((data) => {
        setPerformanceData(data);
        setIsProcessingPort(false);
      })
      .catch((error) => {
        console.error("There was a problem with the fetch operation:", error);
        setIsProcessingPort(false);
      });
  };

  const handleGenerateInsights = () => {
    if (assets.length === 0 || totalPositionUSD === 0) {
      setShowError(true);
      return;
    } else {
      setShowError(false);
    }
    setIsProcessingInsi(true);
    const requestOptions = {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        presentDate: presentDate,
        assets: assets,
      }),
    };

    fetch("/api/insights", requestOptions)
      .then((response) => {
        if (!response.ok) {
          throw new Error("Network response was not ok");
        }
        return response.json();
      })
      .then((data) => {
        setInsights(data);
        setIsProcessingInsi(false);
      })
      .catch((error) => {
        console.error("There was a problem with the fetch operation:", error);
        setIsProcessingInsi(false);
      });
  };

  const sortedMarketData = [...marketData].sort((a, b) =>
    a.crypto_name.localeCompare(b.crypto_name)
  );

  return (
    <div>
      <div>
        <div style={{ display: "flex", alignItems: "center" }}>
          <Typography variant="h5" component="div" sx={{ fontWeight: "bold" }}>
            Portfolio Details
          </Typography>
          {showError && (
            <Typography
              color="error"
              style={{ fontSize: "0.8rem", marginLeft: "10px" }}
            >
              Error:{" "}
              {assets.length === 0
                ? "No assets in portfolio"
                : "Total position in USD is 0. Please enter valid asset details"}
            </Typography>
          )}
        </div>
        <div>
          <Typography
            variant="subtitle2"
            component="div"
            sx={{ fontWeight: "normal", mt: 1 }}
          >
            Provide details of your current investments to generate personalized
            insights and performance analysis
          </Typography>
        </div>
      </div>
      <Table>
        <TableHead>
          <TableRow>
            <TableCell style={{ width: "15%" }}>Asset Name</TableCell>
            <TableCell style={{ width: "35%" }}>Amount</TableCell>
            <TableCell style={{ width: "20%" }}>Position (BTC)</TableCell>
            <TableCell style={{ width: "20%" }}>Position (USD)</TableCell>
            <TableCell style={{ width: "10%" }}></TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {assets.map((asset, index) => (
            <TableRow key={index}>
              <TableCell>
                <Autocomplete
                  value={asset.assetName}
                  options={sortedMarketData.map((data) => data.crypto_name)}
                  renderInput={(params) => (
                    <TextField
                      {...params}
                      style={input3dEffect}
                      fullWidth
                      size="small"
                    />
                  )}
                  onChange={(event, newValue) => {
                    handleInputChange(index, "assetName", newValue);
                  }}
                  fullWidth
                  size="small"
                />
              </TableCell>
              <TableCell>
                <TextField
                  type="number"
                  style={input3dEffect}
                  value={asset.amount}
                  onChange={(e) =>
                    handleInputChange(index, "amount", e.target.value)
                  }
                  fullWidth
                  size="small"
                  inputProps={{ min: "0" }}
                />
              </TableCell>
              <TableCell>
                {asset.positionBTC.toLocaleString(undefined, {
                  minimumFractionDigits: 2,
                  maximumFractionDigits: 2,
                })}
              </TableCell>
              <TableCell>
                {asset.positionUSD.toLocaleString(undefined, {
                  minimumFractionDigits: 2,
                  maximumFractionDigits: 2,
                })}
              </TableCell>
              <TableCell>
                <IconButton
                  onClick={() => handleDeleteAsset(index)}
                  size="small"
                >
                  <DeleteIcon fontSize="small" />
                </IconButton>
              </TableCell>
            </TableRow>
          ))}
          <TableRow>
            <TableCell
              colSpan={2}
              style={{ textAlign: "center", fontWeight: "bold" }}
            >
              TOTAL PORTFOLIO
            </TableCell>
            <TableCell>
              {totalPositionBTC.toLocaleString(undefined, {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2,
              })}
            </TableCell>
            <TableCell>
              {totalPositionUSD.toLocaleString(undefined, {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2,
              })}
            </TableCell>
            <TableCell></TableCell> {}
          </TableRow>
        </TableBody>
      </Table>
      <Fab
        variant="extended"
        color="primary"
        size="small"
        style={{ marginTop: "20px" }}
        onClick={handleAddNewAsset}
      >
        <AddIcon style={{ marginRight: "5px" }} />
        Add new asset
      </Fab>
      <div
        style={{
          position: "fixed",
          bottom: "16px",
          right: "80px",
          display: "flex",
        }}
      >
        <Fab
          variant="extended"
          color="primary"
          style={{
            backgroundColor: isProcessingPort ? "lightblue" : undefined,
            marginRight: "200px",
          }}
          onClick={handleAnalysis}
          disabled={isProcessingPort}
        >
          {isProcessingPort ? (
            <CircularProgress
              size={24}
              color="inherit"
              style={{ marginRight: "10px" }}
            />
          ) : (
            <BarChartIcon style={{ marginRight: "10px" }} />
          )}
          {isProcessingPort ? "Processing" : "Analyze Performance"}
        </Fab>
        <Fab
          variant="extended"
          color="primary"
          style={{
            position: "fixed",
            bottom: "16px",
            right: "16px",
            backgroundColor: isProcessingInsi ? "lightblue" : undefined,
          }}
          onClick={handleGenerateInsights}
          disabled={isProcessingInsi}
        >
          {isProcessingInsi ? (
            <CircularProgress
              size={24}
              color="inherit"
              style={{ marginRight: "10px" }}
            />
          ) : (
            <PlayArrowIcon style={{ marginRight: "10px" }} />
          )}
          {isProcessingInsi ? "Processing" : "Generate Insights"}
        </Fab>
      </div>
    </div>
  );
}

export default PortfolioInformation;
