import React from "react";
import List from "@mui/material/List";
import Typography from "@mui/material/Typography";
import ListItemIcon from "@mui/material/ListItemIcon";
import ListItemText from "@mui/material/ListItemText";
import LisItemButton from "@mui/material/ListItemButton";
import Divider from "@mui/material/Divider";
import TuneIcon from "@mui/icons-material/Tune";
import BarChartIcon from "@mui/icons-material/BarChart";
import LightbulbIcon from "@mui/icons-material/Lightbulb";
import CircularProgress from "@mui/material/CircularProgress";

function NavItem({ IconComponent, text, loading, onClick, active, disabled }) {
  return (
    <>
      <LisItemButton
        onClick={onClick}
        disabled={disabled}
        sx={{
          "&:hover": {
            backgroundColor: "#E3F2FD",
            "& .MuiListItemText-root": {
              color: "#42A6F5",
            },
          },
          backgroundColor: active ? "#E3F2FD" : "transparent",
        }}
      >
        <ListItemIcon sx={{ minWidth: "32px" }}>
          <IconComponent fontSize="small" />
        </ListItemIcon>
        <ListItemText
          primary={
            <Typography variant="body2" sx={{ fontSize: "0.8rem" }}>
              {text}
              {loading && (
                <CircularProgress size={16} style={{ marginLeft: "15px" }} />
              )}
            </Typography>
          }
        />
      </LisItemButton>
      <Divider />
    </>
  );
}

function NavBarItems({
  isProcessingPort,
  isProcessingInsi,
  currentPage,
  setCurrentPage,
  insights,
  performanceData,
}) {
  const items = [
    {
      Icon: TuneIcon,
      text: "Portfolio Preferences",
      page: "userPreferences",
      loading: false,
    },
    {
      Icon: BarChartIcon,
      text: "Portfolio Performance",
      page: "portfolioPerformance",
      loading: isProcessingPort,
      disabled: performanceData == null,
    },
    {
      Icon: LightbulbIcon,
      text: "Portfolio Insights",
      page: "portfolioInsights",
      loading: isProcessingInsi,
      disabled: insights == null,
    },
  ];

  return (
    <div>
      <List component="nav">
        {items.map((item, index) => (
          <NavItem
            key={index}
            IconComponent={item.Icon}
            text={item.text}
            page={item.page}
            loading={item.loading}
            onClick={() => setCurrentPage(item.page)}
            active={currentPage === item.page}
            disabled={item.disabled}
          />
        ))}
      </List>
    </div>
  );
}

export default NavBarItems;
