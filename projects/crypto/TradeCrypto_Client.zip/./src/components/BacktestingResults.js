import React from "react";
import { Typography, Fab, Grid } from "@mui/material";
import RedoIcon from "@mui/icons-material/Redo";

import LineChart from "./LineChart.js";

function BacktestingResults({ analysisData, setAnalysisReady }) {
  const handleReturn = () => {
    setAnalysisReady(false);
  };

  return (
    <div style={{ margin: "20px 0" }}>
      <div style={{ display: "flex", justifyContent: "space-between" }}>
        <Typography
          variant="subtitle1"
          component="div"
          style={{ fontWeight: "normal" }}
        >
          Performance Backtest
        </Typography>
      </div>

      <Grid container spacing={2}>
        <Grid item xs={12} sm={6} md={6}>
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <Typography variant="h6" style={{ fontSize: "14px" }} gutterBottom>
              Historical Performance
            </Typography>
          </div>
          <LineChart
            data={analysisData}
            label="Historical Performance"
            showBTCControl={true}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={6}>
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
            }}
          >
            <Typography variant="h6" style={{ fontSize: "14px" }} gutterBottom>
              Performance Adjusted by Risk
            </Typography>
          </div>
          <LineChart
            data={analysisData}
            label="Performance Adjusted by Risk"
            showBTCControl={false}
          />
        </Grid>
      </Grid>
      <Fab
        variant="extended"
        color="primary"
        style={{
          position: "fixed",
          bottom: "16px",
          right: "16px",
          backgroundColor: undefined,
        }}
        onClick={handleReturn}
      >
        <RedoIcon style={{ marginRight: "10px" }} />
        Analyze Again
      </Fab>
    </div>
  );
}

export default BacktestingResults;
