import React, { useState, useMemo } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Typography,
  Paper,
} from "@mui/material";
import Tooltip from "@mui/material/Tooltip";
import AddIcon from "@mui/icons-material/Add";
import { ArrowUpward, ArrowDownward } from "@mui/icons-material";

<AddIcon />;
function PortfolioInsights({ insights }) {
  const findExpectedReturn = (tickerName) => {
    const prediction = insights.predictions.find(
      (prediction) => prediction.ticker === tickerName
    );
    return prediction ? parseFloat(prediction.expected_return) : 0;
  };

  const [sortConfig, setSortConfig] = useState({
    field: null,
    direction: null,
  });

  const sortedPortfolios = useMemo(() => {
    let sortableItems = [...insights.new_portfolios];
    if (sortConfig.field && sortConfig.direction) {
      sortableItems.sort((a, b) => {
        let aValue =
          sortConfig.field === "expected_return"
            ? findExpectedReturn(a.new_asset_name)
            : a[sortConfig.field];
        let bValue =
          sortConfig.field === "expected_return"
            ? findExpectedReturn(b.new_asset_name)
            : b[sortConfig.field];

        if (aValue < bValue) {
          return sortConfig.direction === "asc" ? -1 : 1;
        }
        if (aValue > bValue) {
          return sortConfig.direction === "asc" ? 1 : -1;
        }
        return 0;
      });
    }
    return sortableItems;
  }, [insights.new_portfolios, sortConfig]);

  const sortIcon = (field) => {
    if (sortConfig.field === field) {
      if (sortConfig.direction === "asc") {
        return <ArrowUpward fontSize="small" />;
      } else if (sortConfig.direction === "desc") {
        return <ArrowDownward fontSize="small" />;
      }
    }
    return <ArrowUpward fontSize="small" style={{ color: "#ccc" }} />;
  };

  const requestSort = (field) => {
    let direction = "asc";
    if (sortConfig.field === field) {
      if (sortConfig.direction === "asc") {
        direction = "desc";
      } else if (sortConfig.direction === "desc") {
        direction = null;
        field = null;
      }
    }
    setSortConfig({ field, direction });
  };

  return (
    <div>
      <Typography
        variant="h5"
        component="div"
        style={{ fontWeight: "bold", marginBottom: "20px" }}
      >
        Portfolio Insights
      </Typography>
      <Typography
        variant="subtitle1"
        component="div"
        sx={{ fontWeight: "normal", mb: 2 }}
      >
        Optimal crypto selections for your portfolio
      </Typography>
      <Paper style={{ maxHeight: "30vh", overflow: "auto" }}>
        <Table size="small">
          <TableHead>
            <TableRow>
              <TableCell>
                <Tooltip title="The name of the cryptocurrency">
                  <span>Crypto Name</span>
                </Tooltip>
              </TableCell>
              <TableCell onClick={() => requestSort("expected_return")}>
                <Tooltip title="Estimated return over the next 6 months with enhanced asset mix">
                  <span>
                    Expected Return (6M) {sortIcon("expected_return")}
                  </span>
                </Tooltip>
              </TableCell>
              <TableCell onClick={() => requestSort("new_asset_sharpe_change")}>
                <Tooltip title="Change in Sharpe Ratio with enhanced asset mix">
                  <span>
                    Sharpe Ratio Δ {sortIcon("new_asset_sharpe_change")}
                  </span>
                </Tooltip>
              </TableCell>
              <TableCell onClick={() => requestSort("new_asset_cr_change")}>
                <Tooltip title="Change in compound return from last year with enhanced asset mix">
                  <span>
                    Past Performance Δ (1Y) {sortIcon("new_asset_cr_change")}
                  </span>
                </Tooltip>
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {sortedPortfolios.map((portfolio, index) => (
              <TableRow
                key={index}
                sx={{
                  "&:hover": {
                    backgroundColor: "#f5f5f5",
                  },
                }}
              >
                <TableCell>{portfolio.new_asset_name}</TableCell>
                <TableCell>
                  {findExpectedReturn(portfolio.new_asset_name).toFixed(2) +
                    "%"}
                </TableCell>
                <TableCell>
                  {portfolio.new_asset_sharpe_change.toFixed(2) + "%"}
                </TableCell>
                <TableCell>
                  {portfolio.new_asset_cr_change.toFixed(2) + "%"}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Paper>
    </div>
  );
}

export default PortfolioInsights;
