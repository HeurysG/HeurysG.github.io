import React from "react";
import { Typography, Grid } from "@mui/material";

import LineChart from "./LineChart.js";
import PieChartComponent from "./PieChartComponent.js";

function PortfolioPerformance({ performanceData }) {
  return (
    <div style={{ margin: "20px 0" }}>
      <div style={{ display: "flex", justifyContent: "space-between" }}>
        <Typography
          variant="subtitle1"
          component="div"
          style={{ fontWeight: "normal" }}
        >
          Portfolio Performance
        </Typography>
      </div>

      <Grid container spacing={2}>
        <Grid item xs={12} sm={6} md={6}>
          <Typography variant="h6" style={{ fontSize: "14px" }} gutterBottom>
            Portfolio Historical Performance
          </Typography>
          <LineChart
            data={performanceData}
            label="Portfolio Historical Performance"
            showBTCControl={true}
          />
        </Grid>
        <Grid item xs={12} sm={6} md={6}>
          <Typography variant="h6" style={{ fontSize: "14px" }} gutterBottom>
            Portfolio Performance Adjusted by Risk
          </Typography>
          <LineChart
            data={performanceData}
            label="Portfolio Performance Adjusted by Risk"
            showBTCControl={false}
          />
        </Grid>

        <Grid item xs={12} sm={6} md={6}>
          <Typography variant="h6" style={{ fontSize: "14px" }} gutterBottom>
            Portfolio Allocation
          </Typography>
          <div>
            <PieChartComponent performanceData={performanceData} />
          </div>
        </Grid>

        <Grid item xs={12} sm={6} md={6}>
          <Typography variant="h6" style={{ fontSize: "14px" }} gutterBottom>
            Historical Drawdown
          </Typography>
          <LineChart
            data={performanceData}
            label="Portfolio Drawdown"
            showBTCControl={true}
          />
        </Grid>
      </Grid>
    </div>
  );
}

export default PortfolioPerformance;
