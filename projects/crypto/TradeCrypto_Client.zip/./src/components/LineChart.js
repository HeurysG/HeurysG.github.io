import React, { useState, useEffect, useRef } from "react";
import {
  Switch,
  FormControlLabel,
  FormGroup,
  Button,
  ButtonGroup,
} from "@mui/material";
import Chart from "chart.js/auto";
import "chartjs-adapter-date-fns";
import { subDays } from "date-fns";

function LineChart({ data, label, showBTCControl }) {
  const [showBTC, setShowBTC] = useState(false);
  const handleSwitchChange = (event) => {
    setShowBTC(event.target.checked);
  };
  const chartRef = useRef(null);
  const chartInstance = useRef(null);
  const [timeFrame, setTimeFrame] = useState("max");

  function normalizeData(values) {
    const baseValue = values[0] / 100 + 1;
    return values.map((value) => ((value / 100 + 1) / baseValue - 1) * 100);
  }

  useEffect(() => {
    if (!data) {
      return;
    }

    const xValues = data.dateRange.map((item) => item);
    let yValues1, yValues2;
    if (label === "Historical Performance") {
      if (showBTC) {
        yValues1 = data.historicalPerformanceInBtc.map(
          (item) => (item.value - 1) * 100
        );
        yValues2 = data.origHistoricalPerformanceInBtc.map(
          (item) => (item.value - 1) * 100
        );
      } else {
        yValues1 = data.historicalPerformance.map(
          (item) => (item.value - 1) * 100
        );

        yValues2 = data.origHistoricalPerformance.map(
          (item) => (item.value - 1) * 100
        );
      }
    } else if (label === "Performance Adjusted by Risk") {
      yValues1 = data.rollingSharpeRatio.map((item) => item.value);
      yValues2 = data.origRollingSharpeRatio.map((item) => item.value);
    } else if (label === "Portfolio Historical Performance") {
      if (showBTC) {
        yValues1 = data.historicalPerformanceInBtc.map(
          (item) => (item.value - 1) * 100
        );
        yValues2 = data.bitcoinPerformance.map((item) => 100);
      } else {
        yValues1 = data.historicalPerformance.map(
          (item) => (item.value - 1) * 100
        );

        yValues2 = data.bitcoinPerformance.map(
          (item) => (item.value - 1) * 100
        );
      }
    } else if (label === "Portfolio Performance Adjusted by Risk") {
      yValues1 = data.rollingSharpeRatio.map((item) => item.value);
      yValues2 = data.bitcoinSharpe.map((item) => item.value);
    } else if (label === "Portfolio Drawdown") {
      if (showBTC) {
        yValues1 = data.drawdownInBtc.map((item) => -item.value * 100);
        yValues2 = data.bitcoinPerformance.map((item) => 0);
      } else {
        yValues1 = data.drawdown.map((item) => -item.value * 100);
        yValues2 = data.bitcoinDrawdown.map((item) => -item.value * 100);
      }
    }

    let filteredXValues = xValues;
    let filteredYValues1 = yValues1;
    let filteredYValues2 = yValues2;

    if (timeFrame !== "max") {
      const timeFrameMap = { "1 year": 365, "2 years": 730 };
      const dateObjects = data.dateRange.map(
        (dateString) => new Date(dateString)
      );

      const endDate = dateObjects[dateObjects.length - 1];
      const startDate = subDays(endDate, timeFrameMap[timeFrame]);
      const filteredIndices = dateObjects
        .map((date, index) =>
          date >= startDate && date <= endDate ? index : -1
        )
        .filter((index) => index !== -1);

      filteredXValues = filteredIndices.map((index) => xValues[index]);
      filteredYValues1 = filteredIndices.map((index) => yValues1[index]);
      filteredYValues2 = filteredIndices.map((index) => yValues2[index]);

      filteredYValues1 = normalizeData(filteredYValues1);
      filteredYValues2 = normalizeData(filteredYValues2);
    }
    function generateLabel(label) {
      let res1 = "";
      let res2 = "";

      if (
        label === "Historical Performance" ||
        label === "Performance Adjusted by Risk"
      ) {
        res1 = "New Portfolio";
        res2 = "Original Portfolio";
      } else if (
        label === "Portfolio Historical Performance" ||
        label === "Portfolio Performance Adjusted by Risk" ||
        label === "Portfolio Drawdown"
      ) {
        res1 = "Portfolio";
        res2 = "Bitcoin";
      }

      return [res1, res2];
    }
    // Chart data
    const chartData = {
      labels: filteredXValues,
      datasets: [
        {
          label: generateLabel(label)[0],
          data: filteredYValues1,
          borderColor: "rgba(75, 192, 192, 1)",
          borderWidth: 2,
        },
        {
          label: generateLabel(label)[1],
          data: filteredYValues2,
          borderColor: "rgba(255, 99, 132, 1)",
          borderWidth: 2,
        },
      ],
    };

    const ctx = chartRef.current.getContext("2d");

    if (chartInstance.current) {
      chartInstance.current.destroy();
    }

    chartInstance.current = new Chart(ctx, {
      type: "line",
      data: chartData,
      options: {
        scales: {
          x: {
            type: "time",
            time: {
              unit: "month",
              displayFormats: {
                month: "MMM yyyy",
              },
            },
            ticks: {
              source: "auto",
              autoSkip: true,
              maxTicksLimit: 20,
            },
          },
          y: {
            beginAtZero: true,
            ticks: {
              stepSize: 1,
              callback: function (value) {
                return label === "Historical Performance"
                  ? `${Math.round(value)}%`
                  : Math.round(value);
              },
            },
          },
        },
        plugins: {
          legend: {
            align: "start",
            position: "bottom",
          },
          tooltip: {
            callbacks: {
              title: function (tooltipItems) {
                let dateParts = tooltipItems[0].label.split(",");
                let dateWithYear = `${dateParts[0]} ${dateParts[1].trim()}`;
                return dateWithYear;
              },
              label: function (context) {
                let label = context.dataset.label || "";

                if (label) {
                  label += ": ";
                }
                if (context.parsed.y !== null) {
                  label += `${context.parsed.y.toFixed(2)}`;
                  if (label.startsWith("Historical Performance")) {
                    label += "%";
                  }
                }
                return label;
              },
            },
          },
        },
        elements: {
          point: {
            radius: 1,
          },
        },
      },
    });
  }, [data, label, timeFrame, showBTC]);

  const TimeFrameButton = ({ frame }) => {
    return (
      <Button
        size="small"
        variant={timeFrame === frame ? "contained" : "outlined"}
        onClick={() => setTimeFrame(frame)}
      >
        {frame}
      </Button>
    );
  };

  return (
    <div>
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
        }}
      >
        <ButtonGroup
          size="small"
          variant="outlined"
          aria-label="time frame selection"
        >
          <TimeFrameButton frame="max" />
          <TimeFrameButton frame="1 year" />
          <TimeFrameButton frame="2 years" />
        </ButtonGroup>
        {showBTCControl && (
          <FormGroup>
            <FormControlLabel
              control={
                <Switch checked={showBTC} onChange={handleSwitchChange} />
              }
              label="Results in BTC"
            />
          </FormGroup>
        )}
      </div>
      <canvas ref={chartRef} width="400" height="200"></canvas>
    </div>
  );
}

export default LineChart;
