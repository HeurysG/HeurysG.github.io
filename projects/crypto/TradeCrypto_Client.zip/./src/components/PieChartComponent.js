import React, { useState, useEffect } from "react";
import { Pie } from "react-chartjs-2";

function PieChartComponent({ performanceData }) {
  const [chartData, setChartData] = useState({
    labels: [],
    datasets: [
      { data: [], backgroundColor: [], borderColor: [], borderWidth: 1 },
    ],
  });

  useEffect(() => {
    setChartData(transformData(performanceData));
  }, [performanceData]);

  function transformData(performanceData) {
    const colors = [
      "rgba(255, 99, 132, 0.2)",
      "rgba(54, 162, 235, 0.2)",
      "rgba(255, 206, 86, 0.2)",
      "rgba(75, 192, 192, 0.2)",
    ];
    const borderColors = [
      "rgba(255, 99, 132, 1)",
      "rgba(54, 162, 235, 1)",
      "rgba(255, 206, 86, 1)",
      "rgba(75, 192, 192, 1)",
    ];

    return {
      labels: performanceData.assetNames,
      datasets: [
        {
          label: "Asset Allocation",
          data: performanceData.allocs,
          backgroundColor: colors.slice(0, performanceData.assetNames.length),
          borderColor: borderColors.slice(0, performanceData.assetNames.length),
          borderWidth: 1,
        },
      ],
    };
  }
  const options = {
    plugins: {
      tooltip: {
        callbacks: {
          label: function (context) {
            let label = context.label || "";

            if (label) {
              label += ": ";
            }
            if (context.parsed !== null) {
              label += new Intl.NumberFormat("en-US", {
                style: "percent",
                minimumFractionDigits: 2,
                maximumFractionDigits: 2,
              }).format(context.parsed);
            }
            return label;
          },
        },
      },
    },
  };

  return (
    <div style={{ width: "200px", height: "200px" }}>
      <Pie data={chartData} options={options} />
    </div>
  );
}

export default PieChartComponent;
