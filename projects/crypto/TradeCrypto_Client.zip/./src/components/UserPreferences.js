import React, { useState } from "react";
import {
  Select,
  MenuItem,
  TextField,
  InputLabel,
  FormControl,
  Grid,
  Typography,
  Fab,
} from "@mui/material";

import ScienceIcon from "@mui/icons-material/Science";
import { NumericFormat } from "react-number-format";

function UserPreferences({
  preferences,
  setPreferences,
  presentDate,
  setPresentDate,
  setNumberOfTickers,
  setIsTraining,
  setLoadingMessage,
  setIsFetchingMarketData,
  setMarketData,
}) {
  const handleDateChange = (event) => {
    setPresentDate(event.target.value);
  };

  const input3dEffect = {
    borderRadius: "15px",
    boxShadow: "0px 4px 6px rgba(0, 0, 0, 0.1)",
    padding: "12px 12px",
    border: "none",
    fontSize: "14px",
    outline: "none",
    width: "200px",
    textAlign: "center",
  };

  const [showError, setShowError] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");

  const handleInputChange = (name, value) => {
    if (name === "minMarketCap" || name === "maxMarketCap") {
      setPreferences({
        ...preferences,
        [name]: Number(value),
      });
    } else {
      setPreferences({
        ...preferences,
        [name]: value,
      });
    }
  };

  const handleTrainModels = () => {
    if (
      !presentDate ||
      !preferences.riskTolerance ||
      !preferences.minMarketCap ||
      !preferences.maxMarketCap
    ) {
      setShowError(true);
      setErrorMessage(
        "Please enter your preferences to train the market models"
      );
      return;
    }

    if (
      preferences.minMarketCap < 100000000 ||
      preferences.minMarketCap > 10000000000 ||
      preferences.maxMarketCap < 100000000 ||
      preferences.maxMarketCap < preferences.minMarketCap
    ) {
      setShowError(true);
      setErrorMessage(
        "Please enter marketcaps within the range of 100 million to 1 trillion"
      );
      return;
    }

    setShowError(false);

    setIsFetchingMarketData(true);
    setLoadingMessage("Fetching current market data...");

    const url =
      `/api/fetchMarketData?` +
      `presentDate=${encodeURIComponent(presentDate)}&` +
      `riskTolerance=${encodeURIComponent(preferences.riskTolerance)}&` +
      `minMarketCap=${encodeURIComponent(preferences.minMarketCap)}&` +
      `maxMarketCap=${encodeURIComponent(preferences.maxMarketCap)}`;

    fetch(url)
      .then((response) => response.json())
      .then((data) => {
        setMarketData(data.marketData);
        setNumberOfTickers(data.nTickersToPredict);
        setLoadingMessage("Training market models...");
        setIsFetchingMarketData(false);
        setIsTraining(true);
        return fetch("/api/train", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            presentDate: presentDate,
            riskTolerance: preferences.riskTolerance,
            minMarketCap: preferences.minMarketCap,
            maxMarketCap: preferences.maxMarketCap,
          }),
        });
      })
      .then(() => {
        setIsFetchingMarketData(false);
        setIsTraining(false);
        setIsFetchingMarketData(false);
      })
      .catch((error) => {
        console.error("Error during fetch or train process:", error);
        setIsFetchingMarketData(false);
        setIsTraining(false);
        setIsFetchingMarketData(false);
      });
  };

  return (
    <div>
      <div style={{ display: "flex", alignItems: "center" }}>
        <Typography variant="h5" component="div" sx={{ fontWeight: "bold" }}>
          User Preferences
        </Typography>
        {showError && (
          <Typography
            color="error"
            style={{ fontSize: "0.8rem", marginLeft: "10px" }}
          >
            Error: {errorMessage}
          </Typography>
        )}
      </div>
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          alignItems: "start",
        }}
      >
        <Typography
          variant="subtitle3"
          style={{ marginTop: "30px", marginBottom: "12px" }}
        >
          Our system's data range spans from January 1, 2016, to November 2,
          2020. For accurate model training and analysis, please specify
          'today's' date within this range.
        </Typography>
        <TextField
          label="Select a Date"
          type="date"
          defaultValue=""
          InputLabelProps={{
            shrink: true,
          }}
          inputProps={{
            min: "2016-01-01",
            max: "2020-11-02",
          }}
          onChange={handleDateChange}
        />
      </div>

      <div
        style={{
          display: "flex",
          flexDirection: "column",
          alignItems: "start",
        }}
      >
        <Typography variant="subtitle3" style={{ marginTop: "30px" }}>
          Select your risk tolerance better match our recommendations with your
          investment preferences
        </Typography>
        <FormControl fullWidth variant="outlined" style={input3dEffect}>
          <InputLabel>Risk Tolerance</InputLabel>
          <Select
            value={preferences.riskTolerance}
            size="small"
            onChange={(e) => handleInputChange("riskTolerance", e.target.value)}
            label="Risk Tolerance"
          >
            <MenuItem value={"conservative"}>Conservative</MenuItem>
            <MenuItem value={"moderate"}>Moderate</MenuItem>
            <MenuItem value={"aggressive"}>Aggressive</MenuItem>
          </Select>
        </FormControl>
      </div>

      <div
        style={{
          display: "flex",
          flexDirection: "column",
          alignItems: "start",
        }}
      >
        <Typography
          variant="subtitle3"
          style={{ marginTop: "30px", marginBottom: "20px" }}
        >
          Specify the min and max market capitalization for the cryptos under
          analysis. This serves as an initial screening of crypto assets. We
          recommend setting the range from 1 billion USD to 1 trillion USD to
          optimize training duration.
        </Typography>
        <Grid container spacing={2}>
          <Grid item xs={4}>
            <NumericFormat
              fullWidth
              label="Min Market Cap"
              size="small"
              variant="outlined"
              customInput={TextField}
              style={input3dEffect}
              thousandSeparator={true}
              value={preferences.minMarketCap}
              onValueChange={(values) => {
                const { value } = values;
                handleInputChange("minMarketCap", value);
              }}
            />
          </Grid>
          <Grid item xs={6}>
            <NumericFormat
              fullWidth
              label="Max Market Cap"
              size="small"
              variant="outlined"
              customInput={TextField}
              style={input3dEffect}
              thousandSeparator={true}
              value={preferences.maxMarketCap}
              onValueChange={(values) => {
                const { value } = values;
                handleInputChange("maxMarketCap", value);
              }}
            />
          </Grid>
        </Grid>
      </div>

      <Fab
        variant="extended"
        color="primary"
        style={{
          position: "fixed",
          bottom: "16px",
          right: "16px",
        }}
        onClick={handleTrainModels}
      >
        <ScienceIcon style={{ marginRight: "10px" }} />
        Train models
      </Fab>
    </div>
  );
}

export default UserPreferences;
