import React from "react";
import Avatar from "@mui/material/Avatar";
import Typography from "@mui/material/Typography";
import Box from "@mui/material/Box";

function NavBarProfile({ user }) {
  return (
    <Box
      sx={{
        p: 2,
        alignItems: "center",
        display: "flex",
        flexDirection: "column",
      }}
    >
      <Avatar alt={user.name} src={user.photo} />
      <Typography
        variant="subtitle1"
        component="div"
        sx={{ mt: 1, fontWeight: "bold" }}
      >
        {user.name}
      </Typography>
    </Box>
  );
}

export default NavBarProfile;
