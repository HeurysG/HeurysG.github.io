import React, { useState, useMemo, useEffect } from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  Typography,
  Paper,
  TextField,
  Fab,
  CircularProgress,
  Autocomplete,
} from "@mui/material";
import Tooltip from "@mui/material/Tooltip";
import AddIcon from "@mui/icons-material/Add";
import PlayArrowIcon from "@mui/icons-material/PlayArrow";

<AddIcon />;
function PerformanceBacktesting({
  portfolio,
  insights,
  setAnalysisReady,
  setAnalysisData,
  presentDate,
}) {
  const [isProcessing, setIsProcessing] = useState(false);
  const [showError, setShowError] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");

  const handleFetch = () => {
    // Check if a recommendation is selected
    if (!selectedAsset) {
      setShowError(true);
      setErrorMessage("A recommendation must be selected.");
      return;
    }

    // Check if any allocation is blank
    const allocations = Object.values(portfolioAllocs);
    if (allocations.some((a) => a === "")) {
      setShowError(true);
      setErrorMessage("It is necessary to inform all the allocations.");
      return;
    }

    // Check if the sum of allocations equals 100
    const totalAllocation =
      allocations.reduce((acc, val) => acc + parseFloat(val), 0) +
      parseFloat(recAlloc || "0");
    if (totalAllocation !== 100) {
      setShowError(true);
      setErrorMessage("The sum of all allocations must equal 100%.");
      return;
    }
    setIsProcessing(true);
    setShowError(false);

    const assetNames = portfolio.map((item) => item.assetName);
    const originalAllocs = portfolio.map((item) => item.alloc);

    const requestOptions = {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        presentDate: presentDate,
        selectedAsset: selectedAsset,
        recAlloc: recAlloc,
        assetNames: assetNames,
        newPortfolioAllocs: portfolioAllocs,
        oldPortfolioAllocs: originalAllocs,
      }),
    };

    fetch("/api/backtest", requestOptions)
      .then((response) => {
        if (!response.ok) {
          throw new Error("Network response was not ok");
        }
        return response.json();
      })
      .then((data) => {
        setAnalysisData(data);
        setAnalysisReady(true);
        setIsProcessing(false);
      })
      .catch((error) => {
        console.error("There was a problem with the fetch operation:", error);
        setIsProcessing(false);
      });
  };

  const input3dEffect = {
    borderRadius: "15px",
    boxShadow: "0px 4px 6px rgba(0, 0, 0, 0.1)",
    padding: "12px 12px",
    border: "none",
    fontSize: "14px",
    outline: "none",
    width: "200px",
    textAlign: "center",
  };

  const totalPortfolioUSD = useMemo(() => {
    return portfolio.reduce((total, item) => total + item.positionUSD, 0);
  }, [portfolio]);

  const [selectedAsset, setSelectedAsset] = useState("");
  const [selectedAssetSuggAloc, setSelectedAssetSuggAloc] = useState("");
  const [optimalAllocations, setOptimalAllocations] = useState({});

  useEffect(() => {
    if (selectedAsset) {
      const selectedPortfolio = insights.new_portfolios.find(
        (portfolio) => portfolio.new_asset_name === selectedAsset
      );
      if (selectedPortfolio) {
        setOptimalAllocations(selectedPortfolio.rebalancing_allocs);
        setSelectedAssetSuggAloc(selectedPortfolio.new_asset_alloc);
      }
    } else {
      setOptimalAllocations({});
      setSelectedAssetSuggAloc("");
    }
  }, [selectedAsset, insights.new_portfolios]);

  const [recAlloc, setRecAlloc] = useState("");
  const [portfolioAllocs, setPortfolioAllocs] = useState(
    portfolio.reduce((acc, _, index) => {
      acc[index] = "";
      return acc;
    }, {})
  );

  const handleIntegerInput = (identifier, value) => {
    const isValid = /^(100|[1-9]?[0-9])$/.test(value);

    if (value === "" || isValid) {
      if (identifier === "recAlloc") {
        setRecAlloc(value);
      } else {
        setPortfolioAllocs((prev) => ({ ...prev, [identifier]: value }));
      }
    }
  };

  return (
    <div>
      <div>
        <div style={{ display: "flex", alignItems: "center" }}>
          <Typography
            variant="subtitle1"
            component="div"
            sx={{ fontWeight: "normal" }}
          >
            Performance Backtesting
          </Typography>
          {showError && (
            <Typography
              color="error"
              style={{ fontSize: "0.8rem", marginLeft: "10px" }}
            >
              Error: {errorMessage}
            </Typography>
          )}
        </div>
        <div>
          <Typography
            variant="subtitle2"
            component="div"
            sx={{ fontWeight: "normal", mt: 1 }}
          >
            Choose a recommendation to view the suggested portfolio rebalancing
            and check how well it would have worked in the past
          </Typography>
        </div>
      </div>
      <Paper style={{ maxHeight: "25vh", overflow: "auto", marginTop: "20px" }}>
        <Table size="small">
          <TableHead>
            <TableRow>
              <TableCell style={{ width: "40%" }}>
                <Tooltip title="Select a recommendation to backtest performance">
                  <span>Select a Recommendation</span>
                </Tooltip>
              </TableCell>
              <TableCell style={{ width: "30%" }}>
                <Tooltip title="Optimal allocation of the asset in your portfolio according to your portfolio">
                  <span>Suggested Allocation</span>
                </Tooltip>
              </TableCell>
              <TableCell style={{ width: "30%" }}>
                <Tooltip title="Enter your desired asset allocation">
                  <span>Asset Allocation</span>
                </Tooltip>
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            <TableRow>
              <TableCell>
                <Tooltip title="Select a recommendation to view optimal allocations and backtest performance">
                  <Autocomplete
                    value={selectedAsset}
                    options={insights.new_portfolios.map(
                      (portfolio) => portfolio.new_asset_name
                    )}
                    renderInput={(params) => (
                      <TextField
                        {...params}
                        style={input3dEffect}
                        fullWidth
                        size="small"
                        InputLabelProps={{
                          shrink: true,
                        }}
                      />
                    )}
                    onChange={(event, newValue) => {
                      setSelectedAsset(newValue);
                    }}
                    fullWidth
                    size="small"
                  />
                </Tooltip>
              </TableCell>
              <TableCell>
                {selectedAssetSuggAloc
                  ? `${(selectedAssetSuggAloc * 100).toFixed(2)}%`
                  : "-"}
              </TableCell>
              <TableCell>
                <TextField
                  type="text"
                  value={recAlloc}
                  onChange={(e) =>
                    handleIntegerInput("recAlloc", e.target.value)
                  }
                  variant="outlined"
                  size="small"
                  placeholder="Enter %"
                />
              </TableCell>
            </TableRow>
          </TableBody>
        </Table>
      </Paper>
      <Paper style={{ maxHeight: "25vh", overflow: "auto", marginTop: "20px" }}>
        <Typography
          variant="subtitle2"
          component="div"
          style={{ padding: "5px", fontWeight: "normal", color: "black" }}
        >
          Portfolio Allocation Analysis
        </Typography>
        <Table size="small">
          <TableHead>
            <TableRow>
              <TableCell style={{ width: "20%" }}>
                <Tooltip title="The name of the cryptocurrency">
                  <span>Crypto Name</span>
                </Tooltip>
              </TableCell>
              <TableCell style={{ width: "20%" }}>
                <Tooltip title="Current allocation of the asset in your portfolio">
                  <span>Current Allocation</span>
                </Tooltip>
              </TableCell>
              <TableCell style={{ width: "30%" }}>
                <Tooltip title="Optimal allocation of the asset in your portfolio based on the selected recommendation">
                  <span>Optimal Allocation</span>
                </Tooltip>
              </TableCell>
              <TableCell style={{ width: "30%" }}>
                <Tooltip title="Enter your desired asset allocation">
                  <span>Asset Allocation</span>
                </Tooltip>
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {portfolio.map((item, index) => {
              const currentAllocation =
                (item.positionUSD / totalPortfolioUSD) * 100;
              const optimalAllocation =
                optimalAllocations[index] !== undefined
                  ? `${(optimalAllocations[index] * 100).toFixed(2)}%`
                  : "-";
              return (
                <TableRow
                  key={index}
                  sx={{
                    "&:hover": {
                      backgroundColor: "#f5f5f5",
                    },
                  }}
                >
                  <TableCell>{item.assetName}</TableCell>
                  <TableCell>{currentAllocation.toFixed(2) + "%"}</TableCell>
                  <TableCell>{optimalAllocation}</TableCell>
                  <TableCell>
                    <TextField
                      type="text"
                      value={portfolioAllocs[index]}
                      onChange={(e) =>
                        handleIntegerInput(index, e.target.value)
                      }
                      variant="outlined"
                      size="small"
                      placeholder="Enter %"
                    />
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </Paper>

      <Fab
        variant="extended"
        color="primary"
        style={{
          position: "fixed",
          bottom: "16px",
          right: "16px",
          backgroundColor: isProcessing ? "lightblue" : undefined,
        }}
        onClick={handleFetch}
        disabled={isProcessing}
      >
        {isProcessing ? (
          <CircularProgress
            size={24}
            color="inherit"
            style={{ marginRight: "10px" }}
          />
        ) : (
          <PlayArrowIcon style={{ marginRight: "10px" }} />
        )}
        {isProcessing ? "Processing" : "Start Analysis"}
      </Fab>
    </div>
  );
}

export default PerformanceBacktesting;
