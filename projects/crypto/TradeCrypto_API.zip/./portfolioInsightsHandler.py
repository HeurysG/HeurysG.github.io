import pandas as pd
from forecaster import Forecaster
import scipy.optimize as opt
import numpy as np
from util import read_data


def get_top_predictions(presentDate):
    data = read_data(include_market_cap=True)
    filtered_data = data[data['market_cap'] > 1e9]
    filtered_data = data[data['trade_date'] < presentDate]

    coin_list = filtered_data['crypto_name'].unique().tolist()

    forecaster = Forecaster()
    forecasts = forecaster.make_predictions(coin_list)
    top_preds = pd.DataFrame(columns=['ticker', 'expected_return'])
    row_index = 0
    for c in coin_list:

        filtered_forecasts = forecasts[forecasts['crypto_name'] == c]
        if len(filtered_forecasts) > 1:
            last_forecast = filtered_forecasts['yhat'].iloc[-1]
            last_trained_value = filtered_forecasts['yhat'].iloc[-180]

            expected_return = 100 * \
                (last_forecast - last_trained_value) / last_trained_value

            top_preds.at[row_index, 'ticker'] = c
            top_preds.at[row_index, 'expected_return'] = expected_return

            row_index += 1

    top_preds = top_preds[top_preds['expected_return'] > 0.0]
    top_preds_sorted = top_preds.sort_values(
        by='expected_return', ascending=False)

    top_20_preds = top_preds_sorted.head(20)
    preds_json = top_20_preds.to_dict(orient='records')
    return preds_json


def optimize_portfolio(portfolio_allocs, preds, presentDate):
    dates = pd.date_range(start=presentDate -
                          pd.Timedelta(days=365), end=presentDate)

    portfolio_tickers = [item['ticker'] for item in portfolio_allocs]
    preds_tickers = [item['ticker'] for item in preds]
    crypto_list = list(set(portfolio_tickers + preds_tickers))

    data = read_data()
    data = data[data['crypto_name'].isin(crypto_list)]

    data = data[data['trade_date'].isin(dates)]

    wide_format = data.pivot(
        index='trade_date', columns='crypto_name', values='price_usd')

    # sum of weights equals 1
    sym_daily_returns = wide_format.copy()
    sym_daily_returns[1:] = (wide_format.iloc[1:] /
                             wide_format.iloc[:-1].values) - 1
    # first date is always 0
    sym_daily_returns.iloc[0] = 0

    # Stats: Curr portfolio Sharpe Ratio

    curr_port_normed = wide_format[portfolio_tickers] / \
        wide_format[portfolio_tickers].iloc[0, :]

    curr_port_daily_rets = sym_daily_returns[portfolio_tickers]
    cov_matrix = curr_port_daily_rets.cov()
    sym_adr = curr_port_daily_rets.mean()

    curr_port_allocs = [item['allocation'] for item in portfolio_allocs]
    curr_port_sharpe = - \
        sharpe_ratio_fx(np.array(curr_port_allocs), sym_adr, cov_matrix)

    # finding portfolio values
    curr_port_alloced = curr_port_normed * np.array(curr_port_allocs)
    curr_port_val = curr_port_alloced.sum(axis=1)
    curr_port_cr = (curr_port_val.iloc[-1] / curr_port_val.iloc[0]) - 1

    new_portfolios_json = []
    for c in preds_tickers:
        if c not in portfolio_tickers:
            curr_crypto_list = list(set(portfolio_tickers + [c]))
            new_port_daily_rets = sym_daily_returns[curr_crypto_list]
            cov_matrix = new_port_daily_rets.cov()
            sym_adr = new_port_daily_rets.mean()
            num_syms = len(portfolio_tickers) + 1
            # search only in the range 0-1
            bound = [0.0, 1.0]
            bounds = [bound for asset in range(num_syms)]
            # sum of weights equals 1
            constraints = ({'type': 'eq', 'fun': lambda x: np.sum(x) - 1})
            # initial guess using equal weights
            initial_allocs = num_syms*[1./num_syms,]

            allocs = opt.minimize(sharpe_ratio_fx, initial_allocs, args=(
                sym_adr, cov_matrix), bounds=bounds, constraints=constraints).x

            # Stats: Change in Sharpe Ratio
            new_port_sharpe = - \
                sharpe_ratio_fx(np.array(allocs), sym_adr, cov_matrix)
            change_sharpe = (new_port_sharpe -
                             curr_port_sharpe) * 100 / new_port_sharpe

            # Stats: Port val
            new_port_sharpe = - \
                sharpe_ratio_fx(np.array(allocs), sym_adr, cov_matrix)
            change_sharpe = (new_port_sharpe -
                             curr_port_sharpe) * 100 / new_port_sharpe

            # finding portfolio values
            new_port_normed = wide_format[curr_crypto_list] / \
                wide_format[curr_crypto_list].iloc[0, :]
            new_port_alloced = new_port_normed * allocs
            new_port_val = new_port_alloced.sum(axis=1)
            new_port_cr = (new_port_val.iloc[-1] / new_port_val.iloc[0]) - 1
            change_cr = 100 * (new_port_cr - curr_port_cr) / new_port_cr

            if allocs[-1] > 0.02:
                allocs_list = allocs.tolist()
                new_port = {
                    "rebalancing_allocs":  allocs_list[:-1],
                    "new_asset_name": c,
                    "new_asset_alloc": allocs_list[-1],
                    "new_asset_sharpe_change": change_sharpe,
                    "new_asset_cr_change": change_cr
                }
                new_portfolios_json.append(new_port)

    return new_portfolios_json


def sharpe_ratio_fx(weights, adr, cov_matrix):
    annualized_returns = np.sum(adr*weights) * 252
    std = np.sqrt(np.dot(weights.T, np.dot(
        cov_matrix, weights))) * np.sqrt(252)
    return -annualized_returns / std
