import os
import pandas as pd
import re


def read_data(include_market_cap=False):
    current_dir = os.path.dirname(__file__)
    file_path = os.path.join(
        current_dir, '..', 'data', 'crypto_tradinds.csv')
    if include_market_cap:
        data = pd.read_csv(file_path, usecols=[
            'trade_date', 'crypto_name', 'price_usd', 'market_cap'])
    else:
        data = pd.read_csv(file_path, usecols=[
            'trade_date', 'crypto_name', 'price_usd'])

    data['trade_date'] = pd.to_datetime(data['trade_date'])

    def remove_special_characters(input_string):
        return re.sub('[^A-Za-z0-9 ]+', '', str(input_string).strip())

    data['crypto_name'] = data['crypto_name'].apply(remove_special_characters)

    return data
