from model import Model
from util import read_data


class Trainer:
    def __init__(self):
        self.data = read_data(include_market_cap=True)

    def train_models(self, cut_off_date, riskTolerance, minMarketCap, maxMarketCap):
        training_data = self.data
        training_data = training_data[(training_data['market_cap'] >= minMarketCap) & (
            training_data['market_cap'] <= maxMarketCap)]

        if riskTolerance != "aggressive":
            training_data['daily_return'] = training_data.groupby(
                'crypto_name')['price_usd'].pct_change()

            volatility = training_data.groupby(
                'crypto_name')['daily_return'].std()

            sorted_cryptos = volatility.sort_values(ascending=False)

            if riskTolerance == 'moderate':
                remove_percentage = 0.15
            else:
                remove_percentage = 0.25

            num_to_remove = int(len(sorted_cryptos) * remove_percentage)

            cryptos_to_remove = sorted_cryptos.head(num_to_remove).index
            training_data = training_data[~training_data['crypto_name'].isin(
                cryptos_to_remove)]
            training_data = training_data.drop(
                columns=['daily_return'])

        coin_list = training_data['crypto_name'].unique().tolist()

        training_data = training_data.drop(
            columns=['market_cap'])

        for c in coin_list:
            crypto_train = training_data[(training_data['crypto_name'] == c) & (
                training_data['trade_date'] < cut_off_date)]
            crypto_train = crypto_train.drop('crypto_name', axis=1)
            crypto_train.columns = ['ds', 'y']

            if len(crypto_train) > 1:
                model_mul = Model()
                model_mul.train(crypto_train)
                model_mul.save(f'{c}_model.pkl')
