from flask import Flask, request, jsonify
import os

from portfolioInsightsHandler import *
from trainer import Trainer
from backtestingHandler import *
import shutil

app = Flask("CryptoAssistantTool")


@app.route('/api/insights', methods=['POST'])
def generate_insights():
    request_data = request.get_json()
    presentDate = pd.to_datetime(request_data['presentDate'])
    assets = request_data['assets']
    total_portfolio_position = sum(asset['positionUSD'] for asset in assets)

    portfolioAllocs = [{'ticker': asset['assetName'],
                        'allocation': asset['positionUSD'] / total_portfolio_position} for asset in assets]

    preds_json = get_top_predictions(presentDate)

    new_portfolios_json = optimize_portfolio(
        portfolioAllocs, preds_json, presentDate)

    response = {
        "predictions": preds_json,
        "new_portfolios": new_portfolios_json
    }
    return jsonify(response)


@app.route('/api/backtest', methods=['POST'])
def performance_backtest():
    request_data = request.get_json()
    selectedAsset = request_data['selectedAsset']
    recAlloc = request_data['recAlloc']
    portAssetNames = request_data['assetNames']
    newPortAllocs = request_data['newPortfolioAllocs']
    origPortAllocs = request_data['oldPortfolioAllocs']

    new_allocs = [float(value) /
                  100 for value in newPortAllocs.values()]

    new_port_tickers = [selectedAsset] + portAssetNames
    new_allocs = [float(recAlloc)/100] + new_allocs

    presentDate = pd.to_datetime(request_data['presentDate'])

    date_list, historical_performance, rolling_sharpe = run_portfolio_backtest(
        presentDate, new_port_tickers, new_allocs)

    first_valid_date = historical_performance.index[0]

    _, original_port_historical_performance, original_port_rolling_sharpe = run_portfolio_backtest(
        presentDate, portAssetNames, origPortAllocs, first_valid_date=first_valid_date)

    historical_performance_btc = get_df_in_btc(historical_performance)
    orig_historical_performance_btc = get_df_in_btc(
        original_port_historical_performance)

    response = {
        'historicalPerformance': historical_performance.to_dict(orient='records'),
        'rollingSharpeRatio': rolling_sharpe.to_dict(orient='records'),
        'dateRange': date_list,
        'origHistoricalPerformance': original_port_historical_performance.to_dict(orient='records'),
        'origRollingSharpeRatio': original_port_rolling_sharpe.to_dict(orient='records'),
        'historicalPerformanceInBtc': historical_performance_btc.to_dict(orient='records'),
        'origHistoricalPerformanceInBtc': orig_historical_performance_btc.to_dict(orient='records'),
    }
    return jsonify(response)


@app.route('/api/performanceAnalysis', methods=['POST'])
def performance_analysis():
    request_data = request.get_json()
    assets = request_data['assets']
    assetNames = [asset['assetName'] for asset in assets]
    allocs = [asset['alloc'] for asset in assets]
    presentDate = pd.to_datetime(request_data['presentDate'])

    date_list, historical_performance, rolling_sharpe = run_portfolio_backtest(
        presentDate, assetNames, allocs)

    historical_performance_btc = get_df_in_btc(
        historical_performance)

    btc_performance, btc_sharpe = get_btc_data(
        historical_performance)

    drawdown = get_drawdown(historical_performance)
    bitcoinDrawdown = get_drawdown(btc_performance)
    drawdownInBtc = get_df_in_btc(drawdown)

    response = {
        'historicalPerformance': historical_performance.to_dict(orient='records'),
        'historicalPerformanceInBtc': historical_performance_btc.to_dict(orient='records'),
        'rollingSharpeRatio': rolling_sharpe.to_dict(orient='records'),
        'dateRange': date_list,
        'bitcoinPerformance': btc_performance.to_dict(orient='records'),
        'bitcoinSharpe': btc_sharpe.to_dict(orient='records'),
        'drawdown': drawdown.to_dict(orient='records'),
        'drawdownInBtc': drawdownInBtc.to_dict(orient='records'),
        'bitcoinDrawdown': bitcoinDrawdown.to_dict(orient='records'),
        'assetNames': assetNames,
        'allocs': allocs,
    }
    return jsonify(response)


@app.route('/api/fetchMarketData', methods=['GET'])
def fetch_market_data():
    presentDate = request.args.get('presentDate', default=None, type=str)
    riskTolerance = request.args.get('riskTolerance', default=None, type=str)
    minMarketCap = request.args.get('minMarketCap', default=None, type=float)
    maxMarketCap = request.args.get('maxMarketCap', default=None, type=float)

    presentDate = pd.to_datetime(presentDate)

    data = read_data(include_market_cap=True)
    filtered_data_market_cap = data[(data['market_cap'] >= minMarketCap) & (
        data['market_cap'] <= maxMarketCap)]

    nTickersToPredict = len(
        filtered_data_market_cap['crypto_name'].unique().tolist())

    if riskTolerance == "moderate":
        nTickersToPredict = int(nTickersToPredict * 0.85)
    elif riskTolerance == "conservative":
        nTickersToPredict = int(nTickersToPredict * 0.75)

    filtered_data_by_date = data[data['trade_date']
                                 == presentDate]
    filtered_data_by_date = filtered_data_by_date.drop(columns=['market_cap'])

    response = {
        "nTickersToPredict": nTickersToPredict,
        "marketData": filtered_data_by_date.to_dict(orient='records')
    }
    return jsonify(response)


@app.route('/api/train', methods=['POST'])
def train_models():
    dir = os.path.dirname(__file__)
    dir = os.path.join(dir, 'models')
    if os.path.exists(dir):
        shutil.rmtree(dir)

    request_data = request.get_json()

    presentDate = request_data['presentDate']
    presentDate = pd.to_datetime(presentDate)
    riskTolerance = request_data['riskTolerance']
    minMarketCap = float(request_data.get('minMarketCap', 0.0))
    maxMarketCap = float(request_data.get('maxMarketCap', float('inf')))

    trainer = Trainer()
    trainer.train_models(presentDate, riskTolerance,
                         minMarketCap, maxMarketCap)

    return jsonify({'message': 'Success'})


@app.route('/api/trainingProgress', methods=['GET'])
def get_training_progress():
    dir = os.path.dirname(__file__)
    dir = os.path.join(dir, 'models')
    try:
        files_count = len([name for name in os.listdir(
            dir) if os.path.isfile(os.path.join(dir, name))])
        return jsonify({'filesCount': files_count})
    except FileNotFoundError:
        return jsonify({'filesCount': 0})
    except Exception as e:
        return jsonify({'filesCount': 0})


if __name__ == '__main__':
    app.run(debug=True)
