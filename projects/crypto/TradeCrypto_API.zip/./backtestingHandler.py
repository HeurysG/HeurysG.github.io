import pandas as pd
import numpy as np
from util import read_data


def run_portfolio_backtest(presentDate, portfolio_tickers, allocs, first_valid_date=None):
    start_date = pd.to_datetime("2016-01-01")
    data = read_data()
    data = data[data['crypto_name'].isin(portfolio_tickers)]
    data = data[(data['trade_date'] >= start_date) &
                (data['trade_date'] <= presentDate)]

    wide_format = data.pivot(
        index='trade_date', columns='crypto_name', values='price_usd')

    if not first_valid_date:
        temp_df = wide_format.copy()
        first_valid_date = temp_df.dropna().index[0]

    wide_format = wide_format[wide_format.index >= first_valid_date]

    # sum of weights equals 1
    sym_daily_returns = wide_format.copy()
    sym_daily_returns[1:] = (wide_format.iloc[1:] /
                             wide_format.iloc[:-1].values) - 1
    # first date is always 0
    sym_daily_returns.iloc[0] = 0

    curr_port_normed = wide_format[portfolio_tickers] / \
        wide_format[portfolio_tickers].iloc[0, :]

    curr_port_daily_rets = sym_daily_returns[portfolio_tickers]

    # finding portfolio values

    curr_port_alloced = curr_port_normed * np.array(allocs)
    curr_port_val = curr_port_alloced.sum(axis=1)

    historical_performance = curr_port_val.reset_index()
    historical_performance.columns = ['trade_date', 'value']
    historical_performance.set_index('trade_date', inplace=True)
    historical_performance = historical_performance.replace(np.nan, None)

    window = 30
    rolling_sharpe = (curr_port_daily_rets.rolling(window).mean() /
                      curr_port_daily_rets.rolling(window).std()) * np.sqrt(252)
    # Calculate the average Sharpe Ratio across all cryptos
    rolling_sharpe = rolling_sharpe.mean(axis=1).reset_index()
    rolling_sharpe.columns = ['trade_date', 'value']
    rolling_sharpe.set_index('trade_date', inplace=True)
    rolling_sharpe = rolling_sharpe.replace(np.nan, None)

    date_list = pd.date_range(
        start=first_valid_date, end=presentDate, freq='D').strftime('%Y-%m-%d').tolist()

    return date_list, historical_performance, rolling_sharpe


def get_df_in_btc(portfolio_values):
    data = read_data()
    btc_values = data[data['crypto_name'] ==
                      'Bitcoin'].drop(columns=['crypto_name'])
    btc_values.set_index('trade_date', inplace=True)
    btc_values = btc_values[btc_values.index.isin(portfolio_values.index)]
    btc_values_normalized = btc_values['price_usd'] / \
        btc_values['price_usd'].iloc[0]
    portfolio_in_btc = portfolio_values['value'].divide(
        btc_values_normalized, axis=0)
    portfolio_in_btc = pd.DataFrame(portfolio_in_btc, columns=['value'])
    portfolio_in_btc = portfolio_in_btc.replace(np.nan, None)

    return portfolio_in_btc


def get_btc_data(portfolio_values):
    data = read_data()
    btc_values = data[data['crypto_name'] ==
                      'Bitcoin'].drop(columns=['crypto_name'])
    btc_values.set_index('trade_date', inplace=True)
    btc_values = btc_values[btc_values.index.isin(portfolio_values.index)]
    btc_values_normalized = btc_values['price_usd'] / \
        btc_values['price_usd'].iloc[0]

    btc_performance = btc_values_normalized.to_frame(name='value')

    btc_sharpe = btc_performance.copy()
    btc_sharpe['daily_returns'] = btc_sharpe['value'].pct_change()
    rolling_mean = btc_sharpe['daily_returns'].rolling(window=30).mean()
    rolling_std = btc_sharpe['daily_returns'].rolling(window=30).std()

    btc_sharpe['value'] = rolling_mean / rolling_std
    btc_sharpe = btc_sharpe.drop(columns=['daily_returns'])
    btc_sharpe = btc_sharpe.replace(np.nan, None)

    return btc_performance, btc_sharpe


def get_drawdown(portfolio_values):
    df = portfolio_values.copy()

    cumulative_max = df['value'].cummax()

    # Calculate Drawdown
    drawdown = (cumulative_max - df['value']) / cumulative_max

    drawdown = (cumulative_max - df['value']) / cumulative_max
    # Add Drawdown to DataFrame
    df['value'] = drawdown

    return df
