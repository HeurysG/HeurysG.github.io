from prophet import Prophet
import pickle
import os


class Model:
    def __init__(self):
        self.model = Prophet()

    def save(self, filename):
        dir = os.path.dirname(__file__)
        dir = os.path.join(dir, 'models')
        if not os.path.exists(dir):
            os.makedirs(dir)
        file_path = os.path.join(dir, filename)

        with open(file_path, 'wb') as f:
            pickle.dump(self, f)

    @staticmethod
    def load(filename):
        dir = os.path.dirname(__file__)
        dir = os.path.join(dir, 'models')
        file_path = os.path.join(dir, filename)
        with open(file_path, 'rb') as f:
            loaded_model = pickle.load(f)
        return loaded_model

    def train(self, train_data):
        trained_model = Prophet(daily_seasonality=True,
                                seasonality_mode='multiplicative')
        trained_model.fit(train_data)
        self.model = trained_model
