import pandas as pd
from model import Model
import os
import numpy as np


class Forecaster:

    def make_predictions(self, coin_list):
        forecast_results = pd.DataFrame()

        for c in coin_list:
            try:
                trained_model = Model.load(f'{c}_model.pkl')
            except:
                continue
            future_df = trained_model.model.make_future_dataframe(
                periods=180)

            forecast = trained_model.model.predict(future_df)[['ds', 'yhat']]
            forecast['crypto_name'] = c
            forecast_results = pd.concat(
                [forecast_results, forecast], ignore_index=True)

        return forecast_results

        # trained_model = Model.load(f'AAPL_model.pkl')
        # period = (pd.to_datetime(end_date) -
        #           pd.to_datetime(start_date)).days

        # future_df = trained_model.model.make_future_dataframe(
        #     periods=period + 1)

        # forecast = trained_model.model.predict(
        #     future_df)

        # fig1 = trained_model.model.plot(forecast)

        # fig2 = trained_model.model.plot_components(forecast)
        # plt.show()

        # return forecast

    def evaluate(self, predictions, start_date):

        cut_off_date = pd.to_datetime(start_date)

        # stock_ticker = 'AAPL'
        # yfin = yf.Ticker(stock_ticker)
        # hist = yfin.history(period="max")
        # hist = hist[['Close']]
        # hist.reset_index(level=0, inplace=True)
        # hist['Date'] = pd.to_datetime(
        #     hist['Date'], utc=False).dt.tz_localize(None)
        # actual_data = hist.rename(
        #     {'Date': 'ds', 'Close': 'actual_y'}, axis='columns')

        # merged = pd.merge(actual_data, predictions, on=['ds'])

        current_dir = os.path.dirname(__file__)
        file_path = os.path.join(
            current_dir, '..', 'data', 'crypto_tradinds.csv')
        actual_data = pd.read_csv(file_path, usecols=[
            'trade_date', 'crypto_name', 'price_usd'])
        actual_data['trade_date'] = pd.to_datetime(actual_data['trade_date'])
        actual_data = actual_data.rename(
            columns={'trade_date': 'ds', 'price_usd': 'actual_y'})

        merged = pd.merge(actual_data, predictions, on=['ds', 'crypto_name'])

        in_sample = merged[merged['ds'] < cut_off_date]
        out_of_sample = merged[merged['ds'] >= cut_off_date]

        # Calculate in-sample errors
        in_sample_mae = np.mean(
            np.abs(in_sample['actual_y'] - in_sample['yhat']))
        in_sample_rmse = np.sqrt(
            np.mean((in_sample['actual_y'] - in_sample['yhat']) ** 2))
        in_sample_mape = self.calculate_mape(in_sample)

        # Calculate out-of-sample errors
        out_of_sample_mae = np.mean(
            np.abs(out_of_sample['actual_y'] - out_of_sample['yhat']))
        out_of_sample_rmse = np.sqrt(
            np.mean((out_of_sample['actual_y'] - out_of_sample['yhat']) ** 2))
        out_of_sample_mape = self.calculate_mape(out_of_sample)

        print('In-Sample Errors:', {'MAE': in_sample_mae,
              'RMSE': in_sample_rmse, 'MAPE': in_sample_mape})
        print('Out-of-Sample Errors:', {'MAE': out_of_sample_mae,
              'RMSE': out_of_sample_rmse, 'MAPE': out_of_sample_mape})

    def calculate_mape(self, data):
        non_zero_actual = data[data['actual_y'] != 0]
        if not non_zero_actual.empty:
            return np.mean(np.abs((non_zero_actual['actual_y'] - non_zero_actual['yhat']) / non_zero_actual['actual_y'])) * 100
        else:
            return None
